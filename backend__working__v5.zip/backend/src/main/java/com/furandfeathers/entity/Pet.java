package com.furandfeathers.entity;

import jakarta.persistence.*;
import lombok.*;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "pets")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Pet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String species;
    private String breed;
    private String age;
    private String gender;
    private String location;

    @Column(length = 1000)
    private String description;

    private String status;
    private String imageUrl;   // optional
    private String imagePath;  // local uploads

    @ManyToOne
    @JoinColumn(name = "owner_id")   // foreign key
    @JsonBackReference
    private User owner;
}
