package com.furandfeathers.entity;

import com.furandfeathers.util.Role;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String password;
    private String provider; // "local" or "google"
    private String picture;

    @Enumerated(EnumType.STRING)
    private Role role; // ADOPTER, SHELTER, ADMIN

    @OneToMany(mappedBy = "owner", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    @Builder.Default
    private List<Pet> pets = new ArrayList<>();
}
