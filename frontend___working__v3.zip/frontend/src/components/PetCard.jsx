import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import "../App.css";

const PetCard = ({ pet }) => {
  const { user } = useContext(AuthContext);

  const placeholder = "https://place-puppy.com/300x300";
  const imgSrc = pet.imageUrl || (pet.imagePath ? `http://localhost:8080/${pet.imagePath}` : (pet.image || pet.image_url || placeholder));

  const truncateWords = (text, limit) => {
    if (!text) return "";
    const words = text.split(/\s+/).filter(Boolean);
    if (words.length <= limit) return words.join(' ');
    return words.slice(0, limit).join(' ') + '...';
  };

  const descriptionText = pet.description || `${pet.breed || pet.category} looking for a home.`;
  const shortDesc = truncateWords(descriptionText, 10);

  return (
    <div className="pet-card-clean">
      <div className="pet-img-box">
        <img src={imgSrc} alt={pet.name} />
      </div>

      <div className="pet-info">
        <div className="pet-meta">
          <span className="pet-category">{pet.breed || pet.category || pet.species}</span>
          <span className="pet-dot">•</span>
          <span className="pet-age">{pet.age} years old</span>
        </div>

        <h3 className="pet-name">{pet.name}</h3>
  <p className="pet-desc">{shortDesc}</p>

        <div className="pet-footer">
          <span className="pet-location">{pet.location}</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Link to={`/pet/${pet.id}`} className="pet-btn-link">
              View Pet →
            </Link>
            {user && (
              <button className="pet-favorite-btn">
                ❤️
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PetCard;