// src/components/GoogleLoginButton.js
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import api from "../api";

export default function GoogleLoginButton({ onLogin }) {
  const handleSuccess = async (response) => {
    try {
      console.log("Google login response:", response);
      const res = await api.post("/auth/google", { token: response.credential });
      console.log("Backend response:", res.data);
      if (res.data.status === "success") {
        onLogin(res.data.user, res.data.token);
      } else {
        alert(res.data.message || "Google login failed");
      }
    } catch (error) {
      console.error("Google login error:", error);
      alert("Google login failed. Please try again.");
    }
  };

  // Replace with your actual Google OAuth client ID from Google Cloud Console
  const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID || "1047749868973-5k7qq63t5o34f4usvtj74rfo05t3adlm.apps.googleusercontent.com";

  return (
    <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <GoogleLogin
          onSuccess={handleSuccess}
          onError={(error) => {
            console.error("Google OAuth error:", error);
            alert("Google login failed");
          }}
          theme="outline"
          size="large"
        />
      </div>
    </GoogleOAuthProvider>
  );
}

