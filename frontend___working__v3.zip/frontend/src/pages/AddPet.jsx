import React, { useState } from "react";
import api from "../api";
import "../App.css";

const AddPet = () => {
  const [pet, setPet] = useState({
    name: "",
    species: "",
    breed: "",
    age: "",
    gender: "",
    location: "",
    description: "",
    status: "Available",
    image: null,
  });

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setPet({ ...pet, [name]: files ? files[0] : value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    Object.entries(pet).forEach(([key, value]) => formData.append(key, value));

    await api.post("/pets", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    alert("Pet added successfully!");
  };

  return (
    <div className="form-container">
      <h2>Add New Pet</h2>
      <form onSubmit={handleSubmit} className="pet-form" encType="multipart/form-data">
        <input type="text" name="name" placeholder="Pet Name" onChange={handleChange} required />
        <input type="text" name="species" placeholder="Species" onChange={handleChange} required />
        <input type="text" name="breed" placeholder="Breed" onChange={handleChange} required />
        <input type="text" name="age" placeholder="Age" onChange={handleChange} required />
        <input type="text" name="gender" placeholder="Gender" onChange={handleChange} required />
        <input type="text" name="location" placeholder="Location" onChange={handleChange} required />
        <textarea name="description" placeholder="Description" onChange={handleChange}></textarea>
        <input type="file" name="image" accept="image/*" onChange={handleChange} />
        <button type="submit">Add Pet</button>
      </form>
    </div>
  );
};

export default AddPet;