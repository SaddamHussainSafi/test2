import React from 'react';

export default function DashboardShelter() {
  return <h2>Welcome Shelter — manage your listed pets here!</h2>;
}
