import React from 'react';

export default function DashboardAdmin() {
  return <h2>Admin Panel — verify shelters and moderate listings.</h2>;
}
