import React from 'react';

export default function DashboardAdopter() {
  return <h2>Welcome Adopter — browse and apply for pets!</h2>;
}
