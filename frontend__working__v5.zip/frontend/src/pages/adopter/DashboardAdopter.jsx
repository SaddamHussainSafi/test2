import React, { useEffect, useState } from 'react';
import { fetchCurrentUser } from '../../utils/fetchUser';

export default function DashboardAdopter() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      fetchCurrentUser().then((latest) => latest && setUser(latest));
    }
  }, []);

  if (!user) return <p>Loading...</p>;

  return (
    <div style={{ padding: '30px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px', marginBottom: '20px' }}>
        <img
          src={user.picture || "https://via.placeholder.com/80"}
          alt={user.name}
          style={{ width: '80px', height: '80px', borderRadius: '50%', border: '3px solid #eee', objectFit: 'cover' }}
        />
        <div>
          <h2>Welcome, {user.name}</h2>
          <p>{user.email}</p>
        </div>
      </div>
      <h2>Browse and apply for pets!</h2>
    </div>
  );
}
