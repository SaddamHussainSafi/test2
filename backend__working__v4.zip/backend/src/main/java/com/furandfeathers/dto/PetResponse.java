package com.furandfeathers.dto;

public class PetResponse {
    public Long id;
    public String name;
    public String species;
    public String breed;
    public String age;
    public String gender;
    public String location;
    public String description;
    public String status;
    public String imageUrl;
    public OwnerDTO owner;

    public PetResponse() {}

    public PetResponse(Long id, String name, String species, String breed, String age, String gender, String location, String description, String status, String imageUrl, OwnerDTO owner) {
        this.id = id;
        this.name = name;
        this.species = species;
        this.breed = breed;
        this.age = age;
        this.gender = gender;
        this.location = location;
        this.description = description;
        this.status = status;
        this.imageUrl = imageUrl;
        this.owner = owner;
    }
}
