package com.furandfeathers.controller;

import com.furandfeathers.entity.Pet;
import com.furandfeathers.dto.OwnerDTO;
import com.furandfeathers.dto.PetResponse;
import com.furandfeathers.entity.User;
import com.furandfeathers.repository.PetRepository;
import com.furandfeathers.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/pets")
@CrossOrigin(origins = "http://localhost:5173")
public class PetController {

    @Autowired
    private PetRepository petRepository;
    
    @Autowired
    private UserRepository userRepository;

    // Test endpoint to verify authentication
    @GetMapping("/test")
    public String whoAmI(Principal principal) {
        return "Logged in as: " + principal.getName();
    }

    // 1 Add new pet
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> addPet(
            @RequestPart("name") String name,
            @RequestPart("species") String species,
            @RequestPart("breed") String breed,
            @RequestPart("age") String age,
            @RequestPart("gender") String gender,
            @RequestPart("location") String location,
            @RequestPart("description") String description,
            @RequestPart(value = "status", required = false) String status,
            @RequestPart(value = "image", required = false) MultipartFile image,
            Principal principal
    ) throws IOException {

        User user = userRepository.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        String uploadDir = "uploads/";
        Files.createDirectories(Paths.get(uploadDir));

        String fileName = image != null ? UUID.randomUUID() + "_" + image.getOriginalFilename() : null;
        if (image != null) {
            Files.copy(image.getInputStream(), Paths.get(uploadDir + fileName), StandardCopyOption.REPLACE_EXISTING);
        }

        Pet pet = new Pet();
        pet.setName(name);
        pet.setSpecies(species);
        pet.setBreed(breed);
        pet.setAge(age);
        pet.setGender(gender);
        pet.setLocation(location);
        pet.setDescription(description);
        pet.setStatus(status != null ? status : "Available");
    pet.setImagePath(fileName != null ? uploadDir + fileName : null);
    pet.setImageUrl(fileName != null ? "http://localhost:8080/uploads/" + fileName : null);
        pet.setOwner(user);

        petRepository.save(pet);
        return ResponseEntity.ok("Pet added successfully");
    }

    // 2 All pets (public)
    @GetMapping
    public List<PetResponse> getAllPets() {
        List<Pet> pets = petRepository.findAllWithOwners();
        return pets.stream().map(this::toResponse).toList();
    }

    // 3 Logged-in users pets
    @GetMapping("/my-pets")
    public List<PetResponse> getMyPets(Principal principal) {
        User user = userRepository.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));
        List<Pet> pets = petRepository.findByOwner(user);
        return pets.stream().map(this::toResponse).toList();
    }

    // helper to convert Pet -> PetResponse
    private PetResponse toResponse(Pet p) {
        OwnerDTO owner = null;
        if (p.getOwner() != null) {
            owner = new OwnerDTO(p.getOwner().getId(), p.getOwner().getName(), p.getOwner().getEmail(), p.getOwner().getPicture());
        }
        return new PetResponse(p.getId(), p.getName(), p.getSpecies(), p.getBreed(), p.getAge(), p.getGender(), p.getLocation(), p.getDescription(), p.getStatus(), p.getImageUrl(), owner);
    }

    // 4 Update pet
    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> updatePet(
            @PathVariable Long id,
            @RequestPart("name") String name,
            @RequestPart("species") String species,
            @RequestPart("breed") String breed,
            @RequestPart("age") String age,
            @RequestPart("gender") String gender,
            @RequestPart("location") String location,
            @RequestPart("description") String description,
            @RequestPart(value = "status", required = false) String status,
            @RequestPart(value = "image", required = false) MultipartFile image,
            Principal principal
    ) throws IOException {

        Pet pet = petRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pet not found"));

        if (!pet.getOwner().getEmail().equals(principal.getName()))
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Unauthorized");

        pet.setName(name);
        pet.setSpecies(species);
        pet.setBreed(breed);
        pet.setAge(age);
        pet.setGender(gender);
        pet.setLocation(location);
        pet.setDescription(description);
        pet.setStatus(status != null ? status : pet.getStatus());

        if (image != null && !image.isEmpty()) {
            String uploadDir = "uploads/";
            Files.createDirectories(Paths.get(uploadDir));
            String fileName = UUID.randomUUID() + "_" + image.getOriginalFilename();
            Files.copy(image.getInputStream(), Paths.get(uploadDir + fileName), StandardCopyOption.REPLACE_EXISTING);
            pet.setImagePath(uploadDir + fileName);
            pet.setImageUrl("http://localhost:8080/uploads/" + fileName);
        }

        petRepository.save(pet);
        return ResponseEntity.ok("Pet updated successfully");
    }

    // 5 Delete pet
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePet(@PathVariable Long id, Principal principal) {
        Pet pet = petRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pet not found"));
        if (!pet.getOwner().getEmail().equals(principal.getName()))
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Unauthorized");

        petRepository.delete(pet);
        return ResponseEntity.ok("Pet deleted successfully");
    }
}
