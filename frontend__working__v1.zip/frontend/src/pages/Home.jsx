import React from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div style={{ textAlign: 'center', padding: '50px' }}>
      <h1 style={{ color: 'black' }}>Welcome to Fur & Feathers</h1>
      <p style={{ color: 'black' }}>Find your perfect furry or feathered companion. Adopt, connect, and love.</p>
      <div>
        <Link to="/pets" style={{ margin: '10px', padding: '10px 20px', backgroundColor: '#007bff', color: 'white', textDecoration: 'none', borderRadius: '5px', display: 'inline-block' }}>Browse Pets</Link>
        <Link to="/login" style={{ margin: '10px', padding: '10px 20px', backgroundColor: '#28a745', color: 'white', textDecoration: 'none', borderRadius: '5px', display: 'inline-block' }}>Get Started</Link>
      </div>
    </div>
  );
}
