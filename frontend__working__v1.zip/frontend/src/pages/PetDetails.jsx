import React from 'react';

export default function PetDetails() {
  return <div>Pet Details</div>;
}

