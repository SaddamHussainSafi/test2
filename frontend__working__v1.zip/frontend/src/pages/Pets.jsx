import React from 'react';

export default function Pets() {
  return <div>Pets List</div>;
}

