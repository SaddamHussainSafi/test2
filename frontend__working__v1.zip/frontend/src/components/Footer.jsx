import React from 'react';

export default function Footer() {
  return (
    <footer style={{ backgroundColor: '#f8f9fa', padding: '10px', textAlign: 'center', borderTop: '1px solid #ddd', marginTop: 'auto' }}>
      © 2025 Fur & Feathers
    </footer>
  );
}

