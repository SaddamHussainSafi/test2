import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav style={{ backgroundColor: '#f8f9fa', padding: '10px', borderBottom: '1px solid #ddd' }}>
      <Link to="/" style={{ marginRight: '20px', textDecoration: 'none', color: '#007bff' }}>Home</Link>
      <Link to="/pets" style={{ marginRight: '20px', textDecoration: 'none', color: '#007bff' }}>Pets</Link>
      {user && <Link to="/dashboard" style={{ marginRight: '20px', textDecoration: 'none', color: '#007bff' }}>Dashboard</Link>}
      {user ? (
        <div style={{ float: 'right' }}>
          <span style={{ marginRight: '10px' }}>{user.name}</span>
          <button onClick={handleLogout} style={{ padding: '5px 10px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px' }}>Logout</button>
        </div>
      ) : (
        <div style={{ float: 'right' }}>
          <Link to="/login" style={{ marginRight: '10px', textDecoration: 'none', color: '#007bff' }}>Login</Link>
          <Link to="/register" style={{ textDecoration: 'none', color: '#007bff' }}>Sign Up</Link>
        </div>
      )}
    </nav>
  );
}

