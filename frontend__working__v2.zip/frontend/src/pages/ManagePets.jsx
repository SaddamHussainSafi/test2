import React, { useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function ManagePets() {
  const { user } = useContext(AuthContext);
  const [filter, setFilter] = useState('all');

  // Mock data - replace with actual API calls
  const pets = [
    {
      id: 1,
      name: 'Bella',
      species: 'Dog',
      status: 'available',
      applications: 5,
      addedDate: '2025-10-01',
      image: 'https://via.placeholder.com/100x75?text=Bella'
    },
    {
      id: 2,
      name: 'Max',
      species: 'Dog',
      status: 'adopted',
      applications: 12,
      addedDate: '2025-09-15',
      image: 'https://via.placeholder.com/100x75?text=Max'
    },
    {
      id: 3,
      name: 'Luna',
      species: 'Cat',
      status: 'pending',
      applications: 3,
      addedDate: '2025-10-10',
      image: 'https://via.placeholder.com/100x75?text=Luna'
    },
  ];

  const filteredPets = filter === 'all' ? pets : pets.filter(pet => pet.status === filter);

  const getStatusColor = (status) => {
    switch (status) {
      case 'available': return '#28a745';
      case 'adopted': return '#6c757d';
      case 'pending': return '#ffc107';
      default: return '#6c757d';
    }
  };

  const handleStatusChange = (petId, newStatus) => {
    // Update pet status
    console.log('Changing status for pet', petId, 'to', newStatus);
  };

  if (user?.role !== 'shelter') {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <h1>Access Denied</h1>
        <p>Only shelter accounts can manage pets.</p>
      </div>
    );
  }

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h1>Manage Pets</h1>
        <Link
          to="/add-pet"
          style={{
            padding: '10px 20px',
            backgroundColor: '#28a745',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '4px'
          }}
        >
          Add New Pet
        </Link>
      </div>

      {/* Filter Controls */}
      <div style={{
        backgroundColor: 'white',
        border: '1px solid #ddd',
        borderRadius: '8px',
        padding: '15px',
        marginBottom: '20px'
      }}>
        <h3>Filter Pets</h3>
        <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap' }}>
          <label>
            <input
              type="radio"
              name="filter"
              value="all"
              checked={filter === 'all'}
              onChange={(e) => setFilter(e.target.value)}
            />
            All Pets ({pets.length})
          </label>
          <label>
            <input
              type="radio"
              name="filter"
              value="available"
              checked={filter === 'available'}
              onChange={(e) => setFilter(e.target.value)}
            />
            Available ({pets.filter(p => p.status === 'available').length})
          </label>
          <label>
            <input
              type="radio"
              name="filter"
              value="pending"
              checked={filter === 'pending'}
              onChange={(e) => setFilter(e.target.value)}
            />
            Pending ({pets.filter(p => p.status === 'pending').length})
          </label>
          <label>
            <input
              type="radio"
              name="filter"
              value="adopted"
              checked={filter === 'adopted'}
              onChange={(e) => setFilter(e.target.value)}
            />
            Adopted ({pets.filter(p => p.status === 'adopted').length})
          </label>
        </div>
      </div>

      {/* Pets Table */}
      <div style={{
        backgroundColor: 'white',
        border: '1px solid #ddd',
        borderRadius: '8px',
        overflow: 'hidden'
      }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#f8f9fa' }}>
              <th style={{ padding: '15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Pet</th>
              <th style={{ padding: '15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Species</th>
              <th style={{ padding: '15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Status</th>
              <th style={{ padding: '15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Applications</th>
              <th style={{ padding: '15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Added</th>
              <th style={{ padding: '15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredPets.map(pet => (
              <tr key={pet.id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '15px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <img
                      src={pet.image}
                      alt={pet.name}
                      style={{ width: '60px', height: '45px', objectFit: 'cover', borderRadius: '4px' }}
                    />
                    <span style={{ fontWeight: 'bold' }}>{pet.name}</span>
                  </div>
                </td>
                <td style={{ padding: '15px' }}>{pet.species}</td>
                <td style={{ padding: '15px' }}>
                  <select
                    value={pet.status}
                    onChange={(e) => handleStatusChange(pet.id, e.target.value)}
                    style={{
                      padding: '4px 8px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      backgroundColor: getStatusColor(pet.status),
                      color: 'white'
                    }}
                  >
                    <option value="available">Available</option>
                    <option value="pending">Pending</option>
                    <option value="adopted">Adopted</option>
                  </select>
                </td>
                <td style={{ padding: '15px' }}>{pet.applications}</td>
                <td style={{ padding: '15px' }}>{pet.addedDate}</td>
                <td style={{ padding: '15px' }}>
                  <div style={{ display: 'flex', gap: '5px' }}>
                    <button
                      style={{
                        padding: '4px 8px',
                        backgroundColor: '#007bff',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '12px'
                      }}
                    >
                      Edit
                    </button>
                    <button
                      style={{
                        padding: '4px 8px',
                        backgroundColor: '#dc3545',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '12px'
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredPets.length === 0 && (
          <div style={{
            textAlign: 'center',
            padding: '50px',
            color: '#666'
          }}>
            <h3>No pets found</h3>
            <p>No pets match the selected filter.</p>
          </div>
        )}
      </div>

      {/* Summary Stats */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '15px',
        marginTop: '20px'
      }}>
        <div style={{
          backgroundColor: 'white',
          border: '1px solid #ddd',
          borderRadius: '8px',
          padding: '15px',
          textAlign: 'center'
        }}>
          <h3 style={{ margin: '0 0 10px 0', color: '#28a745' }}>
            {pets.filter(p => p.status === 'available').length}
          </h3>
          <p style={{ margin: 0, color: '#666' }}>Available Pets</p>
        </div>

        <div style={{
          backgroundColor: 'white',
          border: '1px solid #ddd',
          borderRadius: '8px',
          padding: '15px',
          textAlign: 'center'
        }}>
          <h3 style={{ margin: '0 0 10px 0', color: '#ffc107' }}>
            {pets.filter(p => p.status === 'pending').length}
          </h3>
          <p style={{ margin: 0, color: '#666' }}>Pending Adoption</p>
        </div>

        <div style={{
          backgroundColor: 'white',
          border: '1px solid #ddd',
          borderRadius: '8px',
          padding: '15px',
          textAlign: 'center'
        }}>
          <h3 style={{ margin: '0 0 10px 0', color: '#6c757d' }}>
            {pets.filter(p => p.status === 'adopted').length}
          </h3>
          <p style={{ margin: 0, color: '#666' }}>Successfully Adopted</p>
        </div>

        <div style={{
          backgroundColor: 'white',
          border: '1px solid #ddd',
          borderRadius: '8px',
          padding: '15px',
          textAlign: 'center'
        }}>
          <h3 style={{ margin: '0 0 10px 0', color: '#007bff' }}>
            {pets.reduce((sum, pet) => sum + pet.applications, 0)}
          </h3>
          <p style={{ margin: 0, color: '#666' }}>Total Applications</p>
        </div>
      </div>
    </div>
  );
}