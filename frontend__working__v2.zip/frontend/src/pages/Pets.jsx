import React, { useState, useEffect } from "react";
import PetCard from "../components/PetCard";
import api from "../api/api";
import "../App.css";

const PetsPage = () => {
  const [activeFilter, setActiveFilter] = useState("All");
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPets = async () => {
      try {
        const response = await api.get('/pets');
        setPets(response.data);
        setError(null);
      } catch (error) {
        console.error('Error fetching pets:', error);
        setError('Failed to load pets. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    fetchPets();
  }, []);

  const filteredPets =
    activeFilter === "All"
      ? pets
      : pets.filter(
          (pet) =>
            (pet.breed || pet.category || pet.species)?.toLowerCase() ===
            activeFilter.toLowerCase().slice(0, -1)
        );

  if (loading) {
    return (
      <div className="pets-page">
        <div className="filter-bar">
          {["All", "Dogs", "Cats", "Birds", "Others"].map((filter) => (
            <button
              key={filter}
              className={activeFilter === filter ? "active" : ""}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className="pets-grid">
          {[...Array(8)].map((_, index) => (
            <div key={index} className="pet-card-clean" style={{ background: '#f9f9f9' }}>
              <div className="pet-img-box" style={{ background: '#e0e0e0' }}></div>
              <div className="pet-info" style={{ padding: '1.2rem 1.4rem' }}>
                <div style={{ height: '20px', background: '#e0e0e0', marginBottom: '0.5rem' }}></div>
                <div style={{ height: '24px', background: '#e0e0e0', marginBottom: '0.5rem' }}></div>
                <div style={{ height: '40px', background: '#e0e0e0', marginBottom: '1rem' }}></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ height: '16px', width: '100px', background: '#e0e0e0' }}></div>
                  <div style={{ height: '32px', width: '80px', background: '#e0e0e0', borderRadius: '8px' }}></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="pets-page">
        <div className="filter-bar">
          {["All", "Dogs", "Cats", "Birds", "Others"].map((filter) => (
            <button
              key={filter}
              className={activeFilter === filter ? "active" : ""}
            >
              {filter}
            </button>
          ))}
        </div>
        <div style={{ textAlign: 'center', padding: '2rem', color: '#666' }}>
          <div style={{ fontSize: '1.2rem', marginBottom: '1rem' }}>🐾</div>
          <div>{error}</div>
          <button 
            onClick={() => window.location.reload()} 
            style={{ 
              marginTop: '1rem', 
              padding: '0.5rem 1rem', 
              background: '#fc6203', 
              color: 'white', 
              border: 'none', 
              borderRadius: '8px', 
              cursor: 'pointer' 
            }}
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pets-page">
      {/* Page Banner */}
      <div className="pets-banner">
        <div className="banner-content">
          <h1>Find Your Perfect Companion</h1>
          <p>Discover loving pets waiting for their forever homes</p>
        </div>
      </div>

      <div className="filter-bar">
        {["All", "Dogs", "Cats", "Birds", "Others"].map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={activeFilter === filter ? "active" : ""}
          >
            {filter}
          </button>
        ))}
      </div>

      <div className="pets-grid">
        {filteredPets.map((pet) => (
          <PetCard key={pet.id} pet={pet} />
        ))}
      </div>
    </div>
  );
};

export default PetsPage;

