import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function Dashboard() {
  const { user } = useContext(AuthContext);

  if (!user) {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <h1>Please log in to view your dashboard</h1>
        <Link to="/login" style={{
          display: 'inline-block',
          padding: '10px 20px',
          backgroundColor: '#007bff',
          color: 'white',
          textDecoration: 'none',
          borderRadius: '4px',
          marginTop: '15px'
        }}>
          Log In
        </Link>
      </div>
    );
  }

  const isShelter = user.role === 'shelter';

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <h1>Welcome back, {user.name}!</h1>
      <p style={{ color: '#666', marginBottom: '30px' }}>
        {isShelter ? 'Manage your shelter and help pets find homes.' : 'Find your perfect companion and make a difference.'}
      </p>

      {isShelter ? (
        // Shelter Dashboard
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
          {/* Quick Stats */}
          <div style={{
            backgroundColor: 'white',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '20px',
            textAlign: 'center'
          }}>
            <h2 style={{ margin: '0 0 10px 0', color: '#28a745' }}>12</h2>
            <p style={{ margin: 0, color: '#666' }}>Active Pets</p>
          </div>

          <div style={{
            backgroundColor: 'white',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '20px',
            textAlign: 'center'
          }}>
            <h2 style={{ margin: '0 0 10px 0', color: '#ffc107' }}>8</h2>
            <p style={{ margin: 0, color: '#666' }}>Pending Applications</p>
          </div>

          <div style={{
            backgroundColor: 'white',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '20px',
            textAlign: 'center'
          }}>
            <h2 style={{ margin: '0 0 10px 0', color: '#6c757d' }}>25</h2>
            <p style={{ margin: 0, color: '#666' }}>Pets Adopted</p>
          </div>

          {/* Quick Actions */}
          <div style={{
            backgroundColor: 'white',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '20px',
            gridColumn: 'span 3'
          }}>
            <h3>Quick Actions</h3>
            <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap', marginTop: '15px' }}>
              <Link
                to="/add-pet"
                style={{
                  display: 'inline-block',
                  padding: '10px 20px',
                  backgroundColor: '#28a745',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '4px'
                }}
              >
                Add New Pet
              </Link>
              <Link
                to="/manage-pets"
                style={{
                  display: 'inline-block',
                  padding: '10px 20px',
                  backgroundColor: '#007bff',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '4px'
                }}
              >
                Manage Pets
              </Link>
              <Link
                to="/applications"
                style={{
                  display: 'inline-block',
                  padding: '10px 20px',
                  backgroundColor: '#ffc107',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '4px'
                }}
              >
                View Applications
              </Link>
            </div>
          </div>

          {/* Recent Activity */}
          <div style={{
            backgroundColor: 'white',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '20px',
            gridColumn: 'span 3'
          }}>
            <h3>Recent Activity</h3>
            <div style={{ marginTop: '15px' }}>
              <div style={{ padding: '10px', borderBottom: '1px solid #eee' }}>
                <strong>Max</strong> was adopted by John Doe • 2 days ago
              </div>
              <div style={{ padding: '10px', borderBottom: '1px solid #eee' }}>
                New application for <strong>Bella</strong> from Jane Smith • 3 days ago
              </div>
              <div style={{ padding: '10px' }}>
                <strong>Luna</strong> profile updated • 5 days ago
              </div>
            </div>
          </div>
        </div>
      ) : (
        // Adopter Dashboard
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
          {/* Adoption Status */}
          <div style={{
            backgroundColor: 'white',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '20px'
          }}>
            <h3>🎉 Adoption Updates</h3>
            <div style={{ marginTop: '15px' }}>
              <div style={{
                padding: '15px',
                backgroundColor: '#d4edda',
                border: '1px solid #c3e6cb',
                borderRadius: '4px',
                marginBottom: '10px'
              }}>
                <strong>Your application for Bella has been approved!</strong>
                <br />
                <small>Contact Happy Tails Shelter to arrange pickup.</small>
              </div>
              <div style={{
                padding: '15px',
                backgroundColor: '#fff3cd',
                border: '1px solid #ffeaa7',
                borderRadius: '4px'
              }}>
                <strong>Application for Max is under review.</strong>
                <br />
                <small>We'll notify you within 48 hours.</small>
              </div>
            </div>
          </div>

          {/* Suggested Pets */}
          <div style={{
            backgroundColor: 'white',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '20px'
          }}>
            <h3>💝 Suggested for You</h3>
            <div style={{ marginTop: '15px' }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                padding: '10px',
                border: '1px solid #eee',
                borderRadius: '4px',
                marginBottom: '10px'
              }}>
                <img
                  src="https://via.placeholder.com/50x50?text=Dog"
                  alt="Pet"
                  style={{ borderRadius: '4px' }}
                />
                <div>
                  <strong>Charlie</strong> - 1 year old Beagle
                  <br />
                  <small>Based on your interest in Bella</small>
                </div>
              </div>
              <Link
                to="/pets"
                style={{
                  display: 'block',
                  textAlign: 'center',
                  padding: '8px',
                  backgroundColor: '#007bff',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '4px',
                  marginTop: '10px'
                }}
              >
                Browse More Pets
              </Link>
            </div>
          </div>

          {/* Quick Actions */}
          <div style={{
            backgroundColor: 'white',
            border: '1px solid #ddd',
            borderRadius: '8px',
            padding: '20px',
            gridColumn: 'span 2'
          }}>
            <h3>🚀 Quick Actions</h3>
            <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap', marginTop: '15px' }}>
              <Link
                to="/pets"
                style={{
                  display: 'inline-block',
                  padding: '10px 20px',
                  backgroundColor: '#28a745',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '4px'
                }}
              >
                Browse Pets
              </Link>
              <Link
                to="/applications"
                style={{
                  display: 'inline-block',
                  padding: '10px 20px',
                  backgroundColor: '#007bff',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '4px'
                }}
              >
                My Applications
              </Link>
              <Link
                to="/favorites"
                style={{
                  display: 'inline-block',
                  padding: '10px 20px',
                  backgroundColor: '#ffc107',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '4px'
                }}
              >
                My Favorites
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

