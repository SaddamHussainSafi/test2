package com.furandfeathers.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "pets")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Pet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String species;
    private String breed;
    private String age;
    private String gender;
    private String location;
    private String imageUrl;
    private String description;

    @ManyToOne
    @JoinColumn(name = "shelter_id")
    private User shelter;
}
