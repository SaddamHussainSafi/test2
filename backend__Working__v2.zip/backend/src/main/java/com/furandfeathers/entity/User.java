package com.furandfeathers.entity;

import com.furandfeathers.util.Role;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String password;
    private String provider; // "local" or "google"
    private String picture;

    @Enumerated(EnumType.STRING)
    private Role role; // ADOPTER, SHELTER, ADMIN
}
